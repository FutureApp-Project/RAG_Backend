# schemas/Chat_Message.py
from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, TYPE_CHECKING
from datetime import datetime
import uuid
from .user import UserResponse
# Use forward reference:
from enum import Enum

if TYPE_CHECKING:
    from .chat_sessions import ChatSessionResponse

class MessageTypeEnum(str, Enum):
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"

class ChatMessageBase(BaseModel):
    chat_session_id: uuid.UUID
    user_id: int = Field(..., ge=1)
    message_type: MessageTypeEnum = Field(default=MessageTypeEnum.TEXT)
    content: str = Field(..., min_length=1)
    is_user: bool
    audio_url: Optional[HttpUrl] = None
    image_url: Optional[HttpUrl] = None

class ChatMessageCreate(ChatMessageBase):
    pass

class ChatMessageUpdate(BaseModel):
    content: Optional[str] = Field(None, min_length=1)
    audio_url: Optional[HttpUrl] = None
    image_url: Optional[HttpUrl] = None

class ChatMessageResponse(ChatMessageBase):
    id: uuid.UUID
    timestamp: datetime
    user: Optional[UserResponse] = None
    chat_session: Optional["ChatSessionResponse"] = None
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            uuid.UUID: lambda v: str(v)
        }