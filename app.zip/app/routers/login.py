# app/routers/login.py
from fastapi import APIRouter, Request, HTTPException
from app.config.log.log_config import get_logger
from app.services.login_service import login_service
from app.schemas.user import UserLogin, UserCreate

router = APIRouter(prefix="/auth", tags=["authentication"])
logger = get_logger("auth_router")
loginService = login_service

@router.post("/login")
async def login(request: Request, user_credentials: UserLogin):
    """User login endpoint"""
    try:
        route = router.prefix + "/login"
        logger.info(f"Route: {route} | Username: {user_credentials.username}")
        
        result = await loginService.login(
            username=user_credentials.username,
            password=user_credentials.password
        )
        
        if result["status"] == "error":
            logger.warning(f"Login failed for user: {user_credentials.username}")
            raise HTTPException(status_code=401, detail=result["message"])
        
        logger.info(f"Login successful for user: {user_credentials.username}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in login endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/signup")
async def signup(request: Request, user_data: UserCreate):
    """User registration endpoint"""
    try:
        route = router.prefix + "/signup"
        logger.info(f"Route: {route} | Username: {user_data.username}")
        
        # Convert Pydantic model to dict
        user_dict = user_data.dict()
        
        result = await loginService.signup(user_dict)
        
        if result["status"] == "error":
            logger.warning(f"Signup failed for user: {user_data.username}")
            raise HTTPException(status_code=400, detail=result["message"])
        
        logger.info(f"Signup successful for user: {user_data.username}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in signup endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")