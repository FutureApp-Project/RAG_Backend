# schemas/chat_sessions.py
from pydantic import BaseModel, Field, validator
from typing import TYPE_CHECKING, Optional, List
from datetime import datetime
import uuid
from .user import UserResponse

if TYPE_CHECKING:
    from .chat_message import ChatMessageResponse

class ChatSessionBase(BaseModel):
    """Base schema for chat session with validation"""
    title: str = Field(..., min_length=1, max_length=255, description="Title of the chat session")
    user_id: int = Field(..., ge=1, description="ID of the user who owns the session")

    @validator('title')
    def title_not_empty(cls, v):
        """Validate that title is not empty or whitespace"""
        if not v or not v.strip():
            raise ValueError('Chat session title cannot be empty')
        return v.strip()


class ChatSessionCreate(ChatSessionBase):
    """Schema for creating a new chat session"""
    pass


class ChatSessionUpdate(BaseModel):
    """Schema for updating an existing chat session"""
    title: Optional[str] = Field(None, min_length=1, max_length=255, description="New title for the chat session")

    @validator('title')
    def title_not_empty(cls, v):
        """Validate that title is not empty or whitespace if provided"""
        if v is not None:
            if not v.strip():
                raise ValueError('Chat session title cannot be empty')
            return v.strip()
        return v


class ChatSessionResponse(ChatSessionBase):
    """Schema for chat session response with full details"""
    id: uuid.UUID
    created_at: datetime
    user: Optional[UserResponse] = None
    message_count: Optional[int] = Field(0, description="Number of messages in this session")
    last_message_time: Optional[datetime] = Field(None, description="Timestamp of the last message")
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            uuid.UUID: lambda v: str(v) if v else None
        }


class ChatSessionWithMessagesResponse(ChatSessionResponse):
    """Schema for chat session response with embedded messages"""
    messages: List["ChatMessageResponse"] = Field(default_factory=list, description="Messages in this session")
    
    class Config:
        from_attributes = True
        arbitrary_types_allowed = True

class ChatSessionListResponse(BaseModel):
    """Schema for listing multiple chat sessions"""
    sessions: List[ChatSessionResponse]
    total_count: int
    page: Optional[int] = 1
    page_size: Optional[int] = 10
    
    class Config:
        from_attributes = True


class ChatSessionStatsResponse(BaseModel):
    """Schema for chat session statistics"""
    user_id: int
    total_sessions: int
    total_messages: int
    active_sessions: int
    avg_messages_per_session: float
    most_recent_session: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class ChatSessionQuery(BaseModel):
    """Schema for querying chat sessions with filters"""
    user_id: Optional[int] = Field(None, ge=1, description="Filter by user ID")
    start_date: Optional[datetime] = Field(None, description="Filter sessions created after this date")
    end_date: Optional[datetime] = Field(None, description="Filter sessions created before this date")
    search_term: Optional[str] = Field(None, min_length=1, max_length=100, description="Search in session titles")
    page: int = Field(1, ge=1, description="Page number for pagination")
    page_size: int = Field(10, ge=1, le=100, description="Number of items per page")
    
    @validator('end_date')
    def validate_dates(cls, v, values):
        """Validate that end_date is after start_date if both are provided"""
        if 'start_date' in values and values['start_date'] and v:
            if v < values['start_date']:
                raise ValueError('end_date must be after start_date')
        return v
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": 1,
                "start_date": "2024-01-01T00:00:00Z",
                "end_date": "2024-12-31T23:59:59Z",
                "search_term": "medical",
                "page": 1,
                "page_size": 20
            }
        }


class ChatSessionBulkDelete(BaseModel):
    """Schema for bulk deletion of chat sessions"""
    session_ids: List[uuid.UUID] = Field(..., min_items=1, max_items=100, description="List of session IDs to delete")
    
    @validator('session_ids')
    def validate_session_ids(cls, v):
        """Validate that session IDs are not empty"""
        if not v:
            raise ValueError('At least one session ID is required')
        return v
    
    class Config:
        json_schema_extra = {
            "example": {
                "session_ids": [
                    "123e4567-e89b-12d3-a456-426614174000",
                    "123e4567-e89b-12d3-a456-426614174001"
                ]
            }
        }


class ChatSessionExportRequest(BaseModel):
    """Schema for requesting chat session export"""
    session_id: uuid.UUID
    format: str = Field("json", pattern="^(json|csv|pdf)$", description="Export format: json, csv, or pdf")
    include_user_info: bool = Field(False, description="Include user information in export")
    include_timestamps: bool = Field(True, description="Include timestamps in export")
    
    class Config:
        json_schema_extra = {
            "example": {
                "session_id": "123e4567-e89b-12d3-a456-426614174000",
                "format": "json",
                "include_user_info": True,
                "include_timestamps": True
            }
        }


class ChatSessionExportResponse(BaseModel):
    """Schema for chat session export response"""
    session_id: uuid.UUID
    format: str
    download_url: Optional[str] = Field(None, description="URL to download the exported file")
    file_size: Optional[int] = Field(None, description="Size of the exported file in bytes")
    export_date: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        from_attributes = True


class ChatSessionSummaryResponse(BaseModel):
    """Schema for chat session summary"""
    session_id: uuid.UUID
    title: str
    created_at: datetime
    message_count: int
    user_message_count: int
    bot_message_count: int
    first_message_time: Optional[datetime]
    last_message_time: Optional[datetime]
    duration_minutes: Optional[float] = Field(None, description="Duration of session in minutes")
    
    class Config:
        from_attributes = True


class ChatSessionCreateResponse(BaseModel):
    """Schema for chat session creation response"""
    status: str = Field("success", description="Status of the operation")
    message: str = Field("Chat session created successfully", description="Human-readable message")
    session: ChatSessionResponse
    session_url: Optional[str] = Field(None, description="URL to access the new session")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "message": "Chat session created successfully",
                "session": {
                    "id": "123e4567-e89b-12d3-a456-426614174000",
                    "title": "Medical Consultation",
                    "user_id": 1,
                    "created_at": "2024-01-01T10:00:00Z"
                },
                "session_url": "/chat/sessions/123e4567-e89b-12d3-a456-426614174000"
            }
        }


class ChatSessionDeleteResponse(BaseModel):
    """Schema for chat session deletion response"""
    status: str = Field("success", description="Status of the operation")
    message: str = Field("Chat session deleted successfully", description="Human-readable message")
    session_id: uuid.UUID
    deleted_at: datetime = Field(default_factory=datetime.utcnow)
    messages_deleted: Optional[int] = Field(0, description="Number of messages deleted with the session")
    
    class Config:
        from_attributes = True