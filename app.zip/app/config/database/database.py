# app/config/database/database.py
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.future import select
from typing import AsyncGenerator
from app.models.base import Base
from app.models.role import Role
from app.models.user import User
from app.models.chat_message import ChatMessage
from app.models.chat_sessions import ChatSession
from app.models.menu import MenuItem
from app.models.menu_role import menu_role
from app.config.helper.password_helper import password_helper
import os
from app.config.log.log_config import get_logger
from dotenv import load_dotenv

logger = get_logger("database")
load_dotenv()

# Database URL configuration
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise ValueError("DATABASE_URL is not set in environment variables")

# Create asynchronous engine and sessionmaker
engine = create_async_engine(DATABASE_URL, echo=True)

# FIX: Rename this to AsyncSessionLocal to avoid conflict with SQLAlchemy's async_sessionmaker
AsyncSessionLocal = async_sessionmaker(
    bind=engine, 
    class_=AsyncSession,
    expire_on_commit=False
)

async def init_db():
    """Initialize database tables"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Create default roles if they don't exist
    async with AsyncSessionLocal() as db:
        try:
            default_roles = ["admin", "doctor", "patient", "bot"]
            for role_name in default_roles:
                # Check if role exists
                result = await db.execute(select(Role).filter(Role.role == role_name))
                existing_role = result.scalar_one_or_none()
                
                if not existing_role:
                    db_role = Role(role=role_name)
                    db.add(db_role)
            
            # Create default admin menu items
            if not (await db.execute(select(MenuItem))).scalars().first():
                default_menu_items = [
                    {
                        "text": "Ereignisse",
                        "route": "/dashboard",
                        "icon": "bx:bx-show",
                        "item_order": 0
                    },
                    {
                        "text": "Benutzer",
                        "route": "/benutzer",
                        "icon": "bx:bxs-user",
                        "item_order": 1
                    },
                    {
                        "text": "Chat History",
                        "route": "/chat-history",
                        "icon": "chat",
                        "item_order": 2
                    },
                    {
                        "text": "Menü",
                        "route": "/menu",
                        "icon": "ic:twotone-menu-book",
                        "item_order": 3
                    },
                    {
                        "text": "Rolle",
                        "route": "/roles",
                        "icon": "fa-solid:user-cog",
                        "item_order": 4
                    },
                    {
                        "text": "FAQ",
                        "route": "/faq",
                        "icon": "mdi:question-mark-circle-outline",
                        "item_order": 5
                    },
                    {
                        "text": "Daten einspeisen",
                        "route": "/upload",
                        "icon": "mdi:upload",
                        "item_order": 6
                    }
                ]
                
                for item_data in default_menu_items:
                    menu_item = MenuItem(**item_data)
                    db.add(menu_item)
                
                await db.commit()
                
                # Assign all menu items to admin role
                admin_role = (await db.execute(select(Role).filter(Role.role == "admin"))).scalar_one_or_none()
                if admin_role:
                    all_menu_items = (await db.execute(select(MenuItem))).scalars().all()
                    admin_role.menu_items.extend(all_menu_items)
            
            await db.commit()
        except Exception as e:
            await db.rollback()
            raise e
        
    # Create default users
    async with AsyncSessionLocal() as db:
        try:
            # Get bot role
            result = await db.execute(select(Role).filter(Role.role == "bot"))
            bot_role = result.scalar_one_or_none()
            
            # Get admin role
            result = await db.execute(select(Role).filter(Role.role == "admin"))
            admin_role = result.scalar_one_or_none()
            
            # Log if roles are missing
            if not admin_role:
                logger.warning("Admin role not found. Please ensure roles are created first.")
            if not bot_role:
                logger.warning("Bot role not found. Please ensure roles are created first.")
            
            # Create bot user if it doesn't exist
            result = await db.execute(select(User).filter(User.username == "bot"))
            bot_user = result.scalar_one_or_none()
            
            if not bot_user and bot_role:
                # Hash the password
                hashed_password = await password_helper.get_password_hash("botpassword")
                
                # Create bot user with all required fields
                bot = User(
                    username="bot", 
                    firstname="Chat",
                    lastname="Bot",
                    password=hashed_password,
                    role_id=bot_role.id,
                    is_active=True
                )
                db.add(bot)
                logger.info("Bot user created successfully")
            
            # Create admin user if it doesn't exist
            result = await db.execute(select(User).filter(User.username == "Eckhard"))
            admin_user = result.scalar_one_or_none()
            
            if not admin_user and admin_role:
                # Hash the admin password
                hashed_password = await password_helper.get_password_hash("Eckhard123")
                
                # Create admin user with all required fields
                admin = User(
                    username="Eckhard", 
                    firstname="Admin",
                    lastname="User",
                    password=hashed_password,
                    role_id=admin_role.id,
                    is_active=True
                )
                db.add(admin)
                logger.info("Admin user 'Eckhard' created successfully")
            elif admin_user:
                logger.info("Admin user 'Eckhard' already exists")
            
            # If bot user exists but bot_role wasn't fetched earlier, fetch it for logging
            if bot_user and not bot_role:
                result = await db.execute(select(Role).filter(Role.role == "bot"))
                bot_role = result.scalar_one_or_none()
                if bot_user:
                    logger.info("Bot user already exists")
            
            await db.commit()
            
        except Exception as e:
            await db.rollback()
            logger.error(f"Error creating default users: {str(e)}")
            raise e


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency to get async DB session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

# Export commonly used names for convenience
__all__ = ['engine', 'AsyncSessionLocal', 'Base', 'init_db', 'get_db']

# # app/config/database/database.py
# from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
# from sqlalchemy.future import select
# from typing import AsyncGenerator
# from app.models.base import Base
# from app.models.role import Role
# from app.models.user import User
# from app.models.chat_message import ChatMessage
# from app.models.chat_sessions import ChatSession
# from app.models.menu import MenuItem
# from app.models.menu_role import menu_role
# from app.config.helper.password_helper import password_helper
# import os
# from app.config.log.log_config import get_logger
# from dotenv import load_dotenv

# logger = get_logger("database")

# load_dotenv()

# # Database URL configuration
# DATABASE_URL = os.getenv("DATABASE_URL")
# if not DATABASE_URL:
#     raise ValueError("DATABASE_URL is not set in environment variables")

# # Create asynchronous engine and sessionmaker
# engine = create_async_engine(DATABASE_URL, echo=True)

# # FIX: Rename this to AsyncSessionLocal to avoid conflict with SQLAlchemy's async_sessionmaker
# AsyncSessionLocal = async_sessionmaker(
#     bind=engine, class_=AsyncSession, expire_on_commit=False
# )


# async def init_db():
#     """Initialize database tables"""
#     async with engine.begin() as conn:
#         await conn.run_sync(Base.metadata.create_all)

#     # Create default roles if they don't exist
#     async with AsyncSessionLocal() as db:  # Use AsyncSessionLocal here
#         try:
#             default_roles = ["admin", "doctor", "patient", "bot"]
#             for role_name in default_roles:
#                 # Check if role exists
#                 result = await db.execute(select(Role).filter(Role.role == role_name))
#                 existing_role = result.scalar_one_or_none()

#                 if not existing_role:
#                     db_role = Role(role=role_name)
#                     db.add(db_role)
#             # Create default admin menu items
#             if not (await db.execute(select(MenuItem))).scalars().first():
#                 default_menu_items = [
#                     {
#                         "text": "Ereignisse",
#                         "route": "/dashboard",
#                         "icon": "bx:bx-show",
#                         "item_order": 0,
#                     },
#                     {
#                         "text": "Benutzer",
#                         "route": "/benutzer",
#                         "icon": "bx:bxs-user",
#                         "item_order": 1,
#                     },
#                     {
#                         "text": "Chat History",
#                         "route": "/chat-history",
#                         "icon": "chat",
#                         "item_order": 2,
#                     },
#                     {
#                         "text": "Menü",
#                         "route": "/menu",
#                         "icon": "ic:twotone-menu-book",
#                         "item_order": 3,
#                     },
#                     {
#                         "text": "Rolle",
#                         "route": "/roles",
#                         "icon": "fa-solid:user-cog",
#                         "item_order": 4,
#                     },
#                     {
#                         "text": "FAQ",
#                         "route": "/faq",
#                         "icon": "mdi:question-mark-circle-outline",
#                         "item_order": 5,
#                     },
#                     {
#                         "text": "Daten einspeisen",
#                         "route": "/upload",
#                         "icon": "mdi:upload",
#                         "item_order": 6,
#                     },
#                 ]

#                 for item_data in default_menu_items:
#                     menu_item = MenuItem(**item_data)
#                     db.add(menu_item)

#                 await db.commit()

#                 # Assign all menu items to admin role
#                 admin_role = (
#                     await db.execute(select(Role).filter(Role.role == "admin"))
#                 ).scalar_one_or_none()
#                 if admin_role:
#                     all_menu_items = (
#                         (await db.execute(select(MenuItem))).scalars().all()
#                     )
#                     admin_role.menu_items.extend(all_menu_items)
#             await db.flush()
#             await db.commit()
#         except Exception as e:
#             await db.rollback()
#             raise e

#     # write bot user if not exists and password hashing
#     async with AsyncSessionLocal() as db:
#         bot_role = None  # Ensure bot_role is always defined
#         # Get bot user
#         result = await db.execute(select(User).filter(User.username == "bot"))
#         bot_user = result.scalar_one_or_none()

#         if not bot_user:
#             # Get bot role
#             result = await db.execute(select(Role).filter(Role.role == "bot"))
#             bot_role = result.scalar_one_or_none()

#             if bot_role:
#                 # Hash the password
#                 hashed_password = await password_helper.get_password_hash("botpassword")

#                 # Create bot user with all required fields
#                 bot = User(
#                     username="bot",
#                     firstname="Chat",
#                     lastname="Bot",  # Required field
#                     password=hashed_password,  # Hashed password
#                     role_id=bot_role.id,  # Required field
#                     is_active=True,
#                 )
#                 db.add(bot)
#                 await db.commit()
#                 logger.info("Bot user created successfully")
#             else:
#                 logger.error(
#                     "Bot role not found. Please ensure roles are created first."
#                 )
#         else:
#             # If bot_user exists, still try to get bot_role for later checks
#             result = await db.execute(select(Role).filter(Role.role == "bot"))
#             bot_role = result.scalar_one_or_none()

#         # Get admin role
#         result = await db.execute(select(Role).filter(Role.role == "admin"))
#         admin_role = result.scalar_one_or_none()
#         # Create admin user if it doesn't exist
#         result = await db.execute(select(User).filter(User.username == "Eckhard"))
#         admin_user = result.scalar_one_or_none()
#         if not admin_user and admin_role:
#             # Hash the admin password
#             hashed_password = await password_helper.get_password_hash("Eckhard123")
#             # Create admin user with all required fields
#             admin = User(
#                 username="Eckhard",
#                 firstname="Admin",
#                 lastname="User",  # Required field
#                 password=hashed_password,  # Hashed password
#                 role_id=admin_role.id,  # Required field
#                 is_active=True,
#             )
#             db.add(admin)
#             await db.commit()
#             logger.info("Admin user 'Eckhard' created successfully")
#         elif admin_user:
#             logger.info("Admin user 'Eckhard' already exists")
#         # Log if roles are missing
#         if not admin_role:
#             logger.warning(
#                 "Admin role not found. Please ensure roles are created first."
#             )
#         if not bot_role:
#             logger.warning("Bot role not found. Please ensure roles are created first.")


# async def get_db() -> AsyncGenerator[AsyncSession, None]:
#     """Dependency to get async DB session"""
#     async with AsyncSessionLocal() as session:  # Use AsyncSessionLocal here
#         try:
#             yield session
#             await session.commit()
#         except Exception:
#             await session.rollback()
#             raise


# # Export commonly used names for convenience
# __all__ = ["engine", "AsyncSessionLocal", "Base", "init_db", "get_db"]
