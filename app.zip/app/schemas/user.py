# schemas/user.py

from pydantic import BaseModel,  Field, validator
from typing import Optional
from datetime import datetime
from enum import Enum

class UserRoleEnum(str, Enum):
    BOT = "bot"
    ADMIN = "admin"
    DOCTOR = "doctor"
    PATIENT = "patient"

class UserBase(BaseModel):
    firstname: str = Field(..., min_length=1, max_length=50)
    lastname: str = Field(..., min_length=1, max_length=50)
    username: str = Field(..., min_length=3, max_length=50)
    # email: Optional[EmailStr] = Field(None, max_length=100)
    role_id: int = Field(..., ge=1)

class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=100)

class UserUpdate(BaseModel):
    firstname: Optional[str] = Field(None, min_length=1, max_length=50)
    lastname: Optional[str] = Field(None, min_length=1, max_length=50)
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    # email: Optional[EmailStr] = Field(None, max_length=100)
    password: Optional[str] = Field(None, min_length=6, max_length=100)
    role_id: Optional[int] = Field(None, ge=1)
    is_active: Optional[bool] = None

    @validator('password')
    def password_not_empty(cls, v):
        if v is not None and len(v.strip()) == 0:
            raise ValueError('Password cannot be empty')
        return v

class UserLogin(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=1)

class UserResponse(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime
    is_active: bool
    is_deleted: bool
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
# from datetime import datetime
# from pydantic import BaseModel, EmailStr, Field
# from typing import Optional

# class UserBase(BaseModel):
#     firstname: str = Field(..., max_length=50)
#     lastname: str = Field(..., max_length=50)
#     username: str = Field(..., max_length=50)
#     email: Optional[EmailStr] = None
#     role_id: int = Field(..., gt=0, description="Foreign key to roles table")

# class UserCreate(UserBase):
#     password: str = Field(..., min_length=8, description="Hashed password")

# class UserUpdate(BaseModel):
#     firstname: Optional[str] = Field(None, max_length=50)
#     lastname: Optional[str] = Field(None, max_length=50)
#     email: Optional[EmailStr] = None
#     is_active: Optional[bool] = None

# class UserLogin(BaseModel):
#     username: str
#     password: str

# class UserInDB(UserBase):
#     id: int
#     is_active: bool
#     is_deleted: bool
#     created_at: datetime
#     updated_at: datetime
    
#     class Config:
#         from_attributes = True

# class UserResponse(UserInDB):
#     pass

# class UserWithRole(UserResponse):
#     from .role import RoleResponse
#     role: Optional[RoleResponse] = None