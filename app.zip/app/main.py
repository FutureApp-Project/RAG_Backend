import os
from fastapi import FastAPI
from contextlib import asynccontextmanager
from apscheduler.schedulers.asyncio import AsyncIOScheduler  # type: ignore
from app.config.log.cleanup import delete_old_logs
from app.routers import chat, login, upload
from app.config.database.database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown events"""
    # Startup
    # Ensure 'logs' and 'chromadb' directories exist at startup
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for folder in ["logs", "chromadb", "imagefiles", "audiofiles", "uploadfiles"]:
        os.makedirs(os.path.join(BASE_DIR, folder), exist_ok=True)

    # Initialize scheduler
    scheduler = AsyncIOScheduler()
    # Note: APScheduler doesn't support async jobs directly, so we wrap it
    scheduler.add_job(delete_old_logs, "interval", days=1)
    scheduler.start()

    # Initialize database
    await init_db()

    print("Application startup complete")
    yield

    # Shutdown
    scheduler.shutdown()
    print("Application shutdown complete")


# Use lifespan parameter instead of deprecated on_startup/on_shutdown
app = FastAPI(lifespan=lifespan)

app.include_router(chat.router)
app.include_router(login.router)
app.include_router(upload.router)


@app.get("/")
async def home():
    return {"status": "Logging system running"}
