# app/services/chat_service.py
import os
from typing import Dict, Any, Optional, List
from datetime import datetime
import uuid

from sqlalchemy import select

from app.config.log.log_config import get_logger
from app.services.vector_store_service import VectorStoreService
from app.services.audio_service import AudioService
from app.services.image_service import ImageService
from app.config.database.database import async_sessionmaker
from app.models.chat_message import ChatMessage
from app.models.chat_sessions import ChatSession  

logger = get_logger("chat_service")

class ChatService:
    def __init__(self):
        self.vector_store = VectorStoreService()
        self.audio_service = AudioService()
        self.image_service = ImageService()
        logger.info("ChatService initialized with medical image analysis")
    
    async def process_message(
        self, 
        user_id: int,
        message_type: str,
        content: str,
        session_id: Optional[uuid.UUID] = None,
        image_type: str = "skin"  # Added: specify if it's skin/scalp image
    ) -> Dict[str, Any]:
        """Process incoming message with enhanced medical image analysis"""
        try:
            logger.info(f"Processing {message_type} message from user {user_id}")
            
            # Get or create session
            chat_session = await self._get_or_create_session(user_id, session_id)
            
            # Process based on message type
            processed_text = content
            image_analysis_result = None
            
            if message_type == "audio":
                # Convert audio to text
                logger.info("Converting audio to text...")
                processed_text = self.audio_service.convert_audio_to_text(
                    content.encode() if isinstance(content, str) else content
                )
                logger.info(f"Audio converted to text: {processed_text[:100]}...")
            
            elif message_type == "image":
                # Medical image analysis for skin/scalp conditions
                logger.info(f"Performing medical image analysis for {image_type}...")
                image_analysis_result = self.image_service.process_base64_image(
                    content, 
                    analyze_medical=True,
                    image_type=image_type
                )
                
                # Generate query from image analysis
                if image_analysis_result and "detected_conditions" in image_analysis_result:
                    conditions = [c["condition"] for c in image_analysis_result["detected_conditions"][:2]]
                    processed_text = f"Image shows possible {', '.join(conditions)}. "
                    processed_text += f"What is {conditions[0] if conditions else 'this condition'} and how to treat it?"
                else:
                    processed_text = "I've uploaded an image of my skin/scalp. Can you analyze it?"
                
                logger.info(f"Medical image analysis completed. Generated query: {processed_text}")
            
            # Save user message with metadata
            user_message = await self._save_message(
                chat_session_id=chat_session.id,
                user_id=user_id,
                content=processed_text,
                message_type=message_type,
                is_user=True,
                original_content=content if message_type != "text" else None,
                metadata={
                    "image_analysis": image_analysis_result if message_type == "image" else None,
                    "image_type": image_type if message_type == "image" else None
                } if message_type == "image" else None
            )
            
            # Query vector database for relevant medical information
            logger.info(f"Searching vector database for: {processed_text[:100]}...")
            vector_results = self.vector_store.query(processed_text, n_results=3)
            
            # Generate response based on vector search AND image analysis
            image_type_for_response = image_type if message_type == "image" else None
            response_text = self._generate_medical_response(
                processed_text, 
                vector_results, 
                image_analysis_result,
                image_type_for_response
            )
            
            # Save bot response
            bot_message = await self._save_message(
                chat_session_id=chat_session.id,
                user_id=user_id,
                content=response_text,
                message_type="text",
                is_user=False,
                metadata={
                    "image_analysis_used": image_analysis_result is not None,
                    "conditions_detected": [
                        c["condition"] for c in image_analysis_result.get("detected_conditions", [])
                    ] if image_analysis_result else [],
                    "vector_results": vector_results
                } if message_type == "image" else {
                    "vector_results": vector_results
                }
            )
            
            logger.info(f"Medical response generated for user {user_id}")
            
            # Prepare response data
            response_data = {
                "session_id": str(chat_session.id),
                "user_message": {
                    "id": str(user_message.id),
                    "content": "[Image uploaded]" if message_type == "image" else content,
                    "processed_text": processed_text,
                    "type": message_type,
                    "timestamp": user_message.timestamp.isoformat()
                },
                "bot_response": {
                    "id": str(bot_message.id),
                    "content": response_text,
                    "timestamp": bot_message.timestamp.isoformat(),
                    "sources_used": len(vector_results.get('results', []))
                },
                "vector_search": {
                    "query": processed_text,
                    "results_count": len(vector_results.get('results', [])),
                    "sources": [
                        {
                            "content": r["content"][:200] + "..." if len(r["content"]) > 200 else r["content"],
                            "source": r["source"],
                            "page": r["page"],
                            "similarity": round(r["similarity_score"], 3)
                        }
                        for r in vector_results.get('results', [])[:3]
                    ] if vector_results.get('results') else []
                }
            }
            
            # Add image analysis results if available
            if message_type == "image" and image_analysis_result:
                response_data["image_analysis"] = {
                    "image_type": image_analysis_result.get("image_type"),
                    "detected_conditions": image_analysis_result.get("detected_conditions", [])[:3],
                    "recommendations": image_analysis_result.get("recommendations", []),
                    "severity": image_analysis_result.get("severity_estimate"),
                    "confidence": image_analysis_result.get("confidence_level")
                }
            
            return response_data
            
        except Exception as e:
            logger.error(f"Error processing medical message: {str(e)}", exc_info=True)
            raise
    
    def _generate_medical_response(self, query: str, vector_results: Dict, 
                                  image_analysis: Optional[Dict] = None, 
                                  image_type: Optional[str] = None) -> str:
        """Generate medical response combining vector results and image analysis"""
        try:
            # Start building response
            response_parts = []
            
            # Add image analysis insights if available
            if image_analysis and image_analysis.get("detected_conditions"):
                conditions = image_analysis["detected_conditions"]
                response_parts.append("**Based on your image analysis:**")
                
                for condition in conditions[:2]:  # Top 2 conditions
                    response_parts.append(
                        f"- Possible {condition['condition']} "
                        f"(confidence: {condition['confidence']*100:.0f}%)"
                    )
                
                # Add recommendations from image analysis
                if image_analysis.get("recommendations"):
                    response_parts.append("\n**Initial recommendations:**")
                    for rec in image_analysis["recommendations"][:3]:
                        response_parts.append(f"• {rec}")
                
                response_parts.append("")
            
            # Add information from vector database
            vector_data = vector_results.get('results', [])
            if vector_data:
                response_parts.append("**Information from medical documents:**")
                
                for i, result in enumerate(vector_data[:2], 1):
                    source_name = os.path.basename(result['source']) if result['source'] != 'Unknown' else 'medical reference'
                    response_parts.append(f"{i}. **Relevance: {result['similarity_score']:.0%}**")
                    response_parts.append(f"   Source: {source_name}")
                    response_parts.append(f"   Content: {result['content'][:300]}...")
                    response_parts.append("")
            else:
                response_parts.append("**General medical information:**")
                response_parts.append(
                    "I couldn't find specific information about this in our medical documents. "
                    "Here's general guidance:"
                )
            
            # Add condition-specific advice based on image type
            if image_type:
                response_parts.append(self._get_condition_specific_advice(image_type, image_analysis))
            
            # Add important disclaimers
            response_parts.append("\n**Important Medical Disclaimer:**")
            response_parts.append("⚠️ This analysis is for informational purposes only.")
            response_parts.append("⚠️ NOT a substitute for professional medical advice.")
            response_parts.append("⚠️ Always consult a qualified healthcare provider.")
            response_parts.append("⚠️ For emergencies, seek immediate medical attention.")
            
            # Add next steps
            response_parts.append("\n**Recommended Next Steps:**")
            response_parts.append("1. Schedule an appointment with a dermatologist")
            response_parts.append("2. Take clear photos from different angles")
            response_parts.append("3. Note any symptoms (itching, pain, duration)")
            response_parts.append("4. Monitor for changes in size, color, or shape")
            
            return "\n".join(response_parts)
            
        except Exception as e:
            logger.error(f"Error generating medical response: {str(e)}")
            return self._generate_fallback_response(query)
    
    def _get_condition_specific_advice(self, image_type: str, image_analysis: Optional[Dict]) -> str:
        """Get specific advice based on image type and analysis"""
        advice = "\n**Care Recommendations:**\n"
        
        if image_type == "skin":
            advice += "• Keep the affected area clean and dry\n"
            advice += "• Avoid scratching or picking at the skin\n"
            advice += "• Use gentle, fragrance-free skincare products\n"
            advice += "• Protect skin from sun exposure with SPF 30+\n"
            
            # Add specific advice if conditions detected
            if image_analysis and image_analysis.get("detected_conditions"):
                conditions = [c["condition"].lower() for c in image_analysis["detected_conditions"]]
                if any(c in ["eczema", "dermatitis"] for c in conditions):
                    advice += "• For eczema: Apply moisturizer immediately after bathing\n"
                if "acne" in conditions:
                    advice += "• For acne: Avoid oily products and wash face twice daily\n"
                if "psoriasis" in conditions:
                    advice += "• For psoriasis: Moisturize regularly and avoid triggers\n"
        
        elif image_type == "scalp":
            advice += "• Use gentle, pH-balanced shampoo\n"
            advice += "• Avoid hot water when washing hair\n"
            advice += "• Don't share combs, brushes, or hats\n"
            advice += "• Reduce stress which can worsen conditions\n"
            
            if image_analysis and image_analysis.get("detected_conditions"):
                conditions = [c["condition"].lower() for c in image_analysis["detected_conditions"]]
                if "dandruff" in conditions:
                    advice += "• For dandruff: Use anti-dandruff shampoo 2-3 times weekly\n"
                if "alopecia" in conditions:
                    advice += "• For hair loss: Consult dermatologist for treatment options\n"
        
        return advice
    
    def _generate_fallback_response(self, query: str) -> str:
        """Generate fallback response when error occurs"""
        return f"I apologize, but I encountered an error while analyzing your query about '{query[:50]}...'. " \
               "Please try again or consult with a healthcare provider for personalized advice."

    async def _get_or_create_session(self, user_id: int, session_id: Optional[uuid.UUID] = None) -> ChatSession:
        """Get existing session or create new one"""
        try:
            async with async_sessionmaker() as session:
                if session_id:
                    # Get existing session
                    result = await session.execute(
                        select(ChatSession).where(
                            ChatSession.id == session_id,
                            ChatSession.user_id == user_id
                        )
                    )
                    chat_session = result.scalar_one_or_none()
                    if chat_session:
                        logger.info(f"Retrieved existing session: {session_id}")
                        return chat_session
                
                # Create new session
                chat_session = ChatSession(
                    user_id=user_id,
                    title=f"Chat Session {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                )
                session.add(chat_session)
                await session.commit()
                await session.refresh(chat_session)
                
                logger.info(f"Created new chat session: {chat_session.id}")
                return chat_session
                
        except Exception as e:
            logger.error(f"Error getting/creating session: {str(e)}")
            raise
    
    async def _save_message(
        self, 
        chat_session_id: uuid.UUID,
        user_id: int,
        content: str,
        message_type: str,
        is_user: bool,
        original_content: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> ChatMessage:
        """Save message to database"""
        try:
            async with async_sessionmaker() as session:
                message = ChatMessage(
                    chat_session_id=chat_session_id,
                    user_id=user_id,
                    message_type=message_type,
                    content=content,
                    is_user=is_user,
                    original_content=original_content,
                    metadata=metadata
                )
                session.add(message)
                await session.commit()
                await session.refresh(message)
                
                logger.debug(f"Message saved: {message.id}, type: {message_type}, user: {is_user}")
                return message
                
        except Exception as e:
            logger.error(f"Error saving message: {str(e)}")
            raise
    
    async def get_chat_history(self, user_id: int, session_id: Optional[uuid.UUID] = None) -> List[Dict]:
        """Get chat history for user"""
        try:
            logger.info(f"Getting chat history for user {user_id}, session: {session_id}")
            
            async with async_sessionmaker() as session:
                # Get all sessions for user
                query = select(ChatSession).where(ChatSession.user_id == user_id)
                
                if session_id:
                    query = query.where(ChatSession.id == session_id)
                
                result = await session.execute(query)
                sessions = result.scalars().all()
                
                history = []
                for sess in sessions:
                    # Get messages for this session
                    messages_query = select(ChatMessage).where(
                        ChatMessage.chat_session_id == sess.id
                    ).order_by(ChatMessage.timestamp)
                    
                    messages_result = await session.execute(messages_query)
                    messages = messages_result.scalars().all()
                    
                    session_data = {
                        "session_id": str(sess.id),
                        "title": sess.title,
                        "created_at": sess.created_at.isoformat(),
                        "messages": [
                            {
                                "id": str(msg.id),
                                "content": msg.content,
                                "type": msg.message_type,
                                "is_user": msg.is_user,
                                "timestamp": msg.timestamp.isoformat(),
                                "original_content": msg.original_content,
                                "metadata": msg.metadata
                            }
                            for msg in messages
                        ]
                    }
                    history.append(session_data)
                
                logger.info(f"Retrieved {len(history)} chat sessions for user {user_id}")
                return history
                
        except Exception as e:
            logger.error(f"Error getting chat history: {str(e)}")
            raise