# schemas/role.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum

class RoleEnum(str, Enum):
    BOT = "bot"
    ADMIN = "admin"
    DOCTOR = "doctor"
    PATIENT = "patient"

class RoleBase(BaseModel):
    role: RoleEnum

class RoleCreate(RoleBase):
    is_active: bool = True

class RoleUpdate(BaseModel):
    role: Optional[RoleEnum] = None
    is_active: Optional[bool] = None

class RoleResponse(RoleBase):
    id: int
    created_at: datetime
    updated_at: datetime
    is_active: bool
    is_deleted: bool
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }