# app/services/audio_service.py

import tempfile
import os
from typing import Optional, Dict, Any
import base64

from app.config.log.log_config import get_logger

logger = get_logger("audio_service")


class AudioService:
    def __init__(self, model_size: str = "base") -> None:
        """
        Initialize AudioService with Whisper for speech recognition.
        
        Requires: pip install openai-whisper
        
        Args:
            model_size: Whisper model size (tiny, base, small, medium, large)
        """
        self.whisper_available: bool = False
        self.model: Any = None
        
        try:
            import whisper  # type: ignore
            
            self.whisper_available = True
            
            # Load Whisper model
            logger.info(f"Loading Whisper model: {model_size}")
            self.model = whisper.load_model(model_size)
            logger.info(f"Whisper model loaded: {model_size}")
            
        except ImportError:
            logger.warning("Whisper not installed. Falling back to simplified mode.")
            logger.warning("Install with: pip install openai-whisper")
            self.whisper_available = False
            self.model = None
            
        except Exception as e:
            logger.error(f"Error loading Whisper model: {str(e)}")
            self.whisper_available = False
            self.model = None
    
    def convert_audio_to_text(self, audio_bytes: bytes, audio_format: str = "wav") -> str:
        """Convert audio bytes to text using Whisper"""
        try:
            logger.info(f"Converting audio to text, format: {audio_format}")
            
            if not self.whisper_available or self.model is None:
                logger.warning("Whisper not available, using fallback")
                return self._fallback_response()
            
            # Validate audio
            validation = self.validate_audio(audio_bytes, audio_format)
            if not validation.get("is_valid", False):
                logger.warning(f"Invalid audio: {validation.get('message')}")
                return f"Invalid audio file: {validation.get('message')}"
            
            # Save audio to temporary file
            with tempfile.NamedTemporaryFile(suffix=f".{audio_format}", delete=False) as tmp_file:
                tmp_file.write(audio_bytes)
                tmp_path = tmp_file.name
            
            try:
                # Transcribe using Whisper
                # Note: whisper.transcribe returns a dict with 'text' key
                result: Dict[str, Any] = self.model.transcribe(  # type: ignore
                    tmp_path,
                    language="en",  # Set language if known
                    task="transcribe",  # or "translate"
                    fp16=False  # Set to True if using GPU
                )
                
                text: str = result.get("text", "").strip()
                if text:
                    logger.info(f"Transcription successful: {text[:100]}...")
                    return text
                else:
                    logger.warning("Transcription returned empty text")
                    return "Could not transcribe audio. No speech detected."
                
            finally:
                # Cleanup temporary file
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
                    
        except Exception as e:
            logger.error(f"Error in Whisper transcription: {str(e)}")
            return self._fallback_response(error=str(e))
    
    def process_base64_audio(self, base64_string: str) -> str:
        """Process base64 encoded audio string"""
        try:
            logger.info("Processing base64 encoded audio")
            
            # Remove data URL prefix if present
            if ',' in base64_string:
                base64_string = base64_string.split(',')[1]
            
            # Decode base64
            audio_bytes: bytes = base64.b64decode(base64_string)
            
            # Try to detect format from data URL
            audio_format: str = "wav"  # default
            if 'data:audio/' in base64_string:
                # Extract format from data URL
                if 'data:audio/wav' in base64_string:
                    audio_format = "wav"
                elif 'data:audio/mp3' in base64_string or 'data:audio/mpeg' in base64_string:
                    audio_format = "mp3"
                elif 'data:audio/ogg' in base64_string:
                    audio_format = "ogg"
                elif 'data:audio/webm' in base64_string:
                    audio_format = "webm"
            
            return self.convert_audio_to_text(audio_bytes, audio_format)
            
        except Exception as e:
            logger.error(f"Error processing base64 audio: {str(e)}")
            return f"Could not process audio: {str(e)}"
    
    def validate_audio(self, audio_bytes: bytes, audio_format: str = "wav") -> Dict[str, Any]:
        """Validate audio file"""
        try:
            validation_result: Dict[str, Any] = {
                "is_valid": False,
                "format": audio_format,
                "size_bytes": len(audio_bytes),
                "message": ""
            }
            
            # Basic size validation
            if len(audio_bytes) == 0:
                validation_result["message"] = "Audio file is empty"
                return validation_result
            
            # Size limits (50MB for Whisper)
            max_size: int = 50 * 1024 * 1024  # 50MB
            if len(audio_bytes) > max_size:
                validation_result["message"] = f"Audio file too large. Max size: {max_size//(1024*1024)}MB"
                return validation_result
            
            # Minimum size (1KB)
            min_size: int = 1024  # 1KB
            if len(audio_bytes) < min_size:
                validation_result["message"] = f"Audio file too small. Min size: {min_size} bytes"
                return validation_result
            
            # Format validation
            supported_formats: list[str] = ["wav", "mp3", "m4a", "ogg", "flac", "webm"]
            if audio_format.lower() not in supported_formats:
                validation_result["message"] = f"Unsupported audio format. Supported: {supported_formats}"
                return validation_result
            
            # Additional checks based on format
            if audio_format.lower() == "wav":
                # Check WAV header (optional, can be complex)
                if len(audio_bytes) > 44 and audio_bytes[:4] != b'RIFF':
                    validation_result["message"] = "Invalid WAV file format"
                    return validation_result
            
            validation_result["is_valid"] = True
            validation_result["message"] = "Audio file is valid"
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Error validating audio: {str(e)}")
            return {
                "is_valid": False,
                "format": audio_format,
                "size_bytes": len(audio_bytes) if audio_bytes else 0,
                "message": f"Validation error: {str(e)}"
            }
    
    def _fallback_response(self, error: Optional[str] = None) -> str:
        """Fallback response when Whisper is not available or fails"""
        import random
        
        base_responses: list[str] = [
            "I received your audio message but speech recognition is not fully configured. "
            "Please ensure Whisper is installed or use text input.",
            
            "Your audio message has been received. The speech recognition service is "
            "currently unavailable. Please use text input instead.",
            
            "Audio input detected. For now, please use text input or ensure that "
            "OpenAI Whisper is properly installed on the server.",
        ]
        
        if error:
            return f"I encountered an error while processing your audio: {error}. Please try text input instead."
        
        return random.choice(base_responses)
    
    def get_audio_info(self, audio_bytes: bytes, audio_format: str = "wav") -> Dict[str, Any]:
        """Get information about the audio file"""
        try:
            return {
                "format": audio_format,
                "size_bytes": len(audio_bytes),
                "size_mb": round(len(audio_bytes) / (1024 * 1024), 2),
                "is_valid": self.validate_audio(audio_bytes, audio_format)["is_valid"],
                "whisper_available": self.whisper_available,
                "model_loaded": self.model is not None
            }
        except Exception as e:
            logger.error(f"Error getting audio info: {str(e)}")
            return {
                "format": audio_format,
                "error": str(e)
            }
    
    def get_supported_formats(self) -> Dict[str, Any]:
        """Get information about supported audio formats"""
        return {
            "supported_formats": ["wav", "mp3", "m4a", "ogg", "flac", "webm"],
            "max_size_mb": 50,
            "recommended_format": "wav",
            "recommended_sample_rate": 16000,
            "recommended_channels": 1,
            "whisper_available": self.whisper_available
        }


# Optional: Create a simplified version for testing without Whisper
class SimpleAudioService:
    """Simplified audio service for testing without Whisper"""
    
    def __init__(self) -> None:
        logger.info("SimpleAudioService initialized (no Whisper dependency)")
    
    def convert_audio_to_text(self, audio_bytes: bytes, audio_format: str = "wav") -> str:
        """Simple placeholder for audio conversion"""
        logger.info(f"Received audio: {len(audio_bytes)} bytes, format: {audio_format}")
        return "Audio processing is disabled in simple mode. Please use text input or install Whisper for speech recognition."
    
    def process_base64_audio(self, base64_string: str) -> str:
        """Process base64 audio in simple mode"""
        logger.info("Processing base64 audio in simple mode")
        return "Audio processing is disabled in simple mode. Please use text input."


# Factory function to create the appropriate audio service
def create_audio_service(use_whisper: bool = True, model_size: str = "base") -> AudioService:
    """
    Factory function to create audio service.
    
    Args:
        use_whisper: Whether to use Whisper (requires installation)
        model_size: Whisper model size if using Whisper
        
    Returns:
        AudioService instance
    """
    if use_whisper:
        try:
           
            logger.info(f"Creating AudioService with Whisper (model: {model_size})")
            return AudioService(model_size=model_size)
        except ImportError:
            logger.warning("Whisper not found, creating SimpleAudioService")
            # Create a dummy object with the same interface
            service = SimpleAudioService()
            service.__class__ = type('AudioService', (AudioService, SimpleAudioService), {})
            return service  # type: ignore
    else:
        logger.info("Creating SimpleAudioService (Whisper disabled)")
        service = SimpleAudioService()
        service.__class__ = type('AudioService', (AudioService, SimpleAudioService), {})
        return service  # type: ignore