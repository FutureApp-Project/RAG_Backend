#app/services/login_service.py
"""
Login service for user authentication and token management.
Uses the common security configuration from app.config.security.
"""

from typing import Dict, Any, Optional
from datetime import timedelta
import jwt
from app.config.log.log_config import get_logger
from app.config.database.database import AsyncSessionLocal
from app.config.security import (
    security_config,
    JWT_SECRET_KEY,
    JWT_ALGORITHM,
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES,
    JWT_REFRESH_TOKEN_EXPIRE_DAYS
)
from app.config.helper.password_helper import password_helper
from app.models.user import User
from app.models.role import Role
from sqlalchemy import select
from sqlalchemy.orm import joinedload  # ADD THIS IMPORT

logger = get_logger("login_service")


class LoginService:
    def __init__(self):
        """Initialize LoginService using common security configuration"""
        self.secret_key = JWT_SECRET_KEY
        self.algorithm = JWT_ALGORITHM
        logger.info("LoginService initialized with common security configuration")
    
    async def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash using password_helper"""
        return await password_helper.verify_password(plain_password, hashed_password)
    
    async def get_password_hash(self, password: str) -> str:
        """Generate password hash using password_helper"""
        return await password_helper.get_password_hash(password)
    
    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate user credentials"""
        try:
            logger.info(f"Authenticating user: {username}")
            
            async with AsyncSessionLocal() as session:
                # Fetch user with role using explicit join
                result = await session.execute(
                    select(User)
                    .join(Role, User.role_id == Role.id)
                    .where(User.username == username)
                    .where(User.is_active == True)
                    .where(User.is_deleted == False)
                    .options(joinedload(User.role))  # This needs the import
                )
                user = result.scalar_one_or_none()
                
                if not user:
                    logger.warning(f"User not found or inactive: {username}")
                    return None
                
                # Verify password
                if not await password_helper.verify_password(password, user.password):
                    logger.warning(f"Invalid password for user: {username}")
                    return None
                
                logger.info(f"User authenticated successfully: {username}, role: {user.role.role}")
                return user
                
        except Exception as e:
            logger.error(f"Error authenticating user {username}: {str(e)}")
            return None
    
    def create_access_token(self, data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token using security_config"""
        try:
            # Use the common security configuration
            if expires_delta:
                token = security_config.create_access_token(data, expires_delta)
            else:
                # Use default expiration from config
                token = security_config.create_access_token(data)
            
            logger.debug(f"Access token created for user: {data.get('sub')}")
            return token
            
        except Exception as e:
            logger.error(f"Error creating access token: {str(e)}")
            raise
    
    def create_refresh_token(self, data: Dict[str, Any]) -> str:
        """Create JWT refresh token using security_config"""
        try:
            token = security_config.create_refresh_token(data)
            logger.debug(f"Refresh token created for user: {data.get('sub')}")
            return token
        except Exception as e:
            logger.error(f"Error creating refresh token: {str(e)}")
            raise
    
    def decode_token(self, token: str) -> Dict[str, Any]:
        """Decode JWT token using security_config"""
        try:
            return security_config.decode_token(token)
        except jwt.ExpiredSignatureError:
            logger.warning("Token has expired")
            raise
        except jwt.InvalidTokenError as e:
            logger.warning(f"Invalid token: {str(e)}")
            raise
    
    async def login(self, username: str, password: str) -> Dict[str, Any]:
        """Perform login and return token"""
        try:
            user = await self.authenticate_user(username, password)
            
            if not user:
                logger.warning(f"Failed login attempt for user: {username}")
                return {
                    "status": "error",
                    "message": "Invalid username or password"
                }
            
            # No need to fetch role separately since we already have it via joinedload
            # user.role is already loaded from the authenticate_user query
            
            # Create tokens
            access_token_expires = timedelta(minutes=JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
            access_token = self.create_access_token(
                data={
                    "sub": user.username,
                    "user_id": user.id,
                    "role": user.role.role,  # Use user.role directly
                    "firstname": user.firstname,
                    "lastname": user.lastname
                },
                expires_delta=access_token_expires
            )
            
            refresh_token = self.create_refresh_token(
                data={
                    "sub": user.username,
                    "user_id": user.id,
                    "role": user.role.role  # Use user.role directly
                }
            )
            
            logger.info(f"Login successful for user: {username}, role: {user.role.role}")
            
            return {
                "status": "success",
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer",
                "expires_in": JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,  # seconds
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "firstname": user.firstname,
                    "lastname": user.lastname,
                    "role": user.role.role,
                    "role_id": user.role_id
                }
            }
            
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            return {
                "status": "error",
                "message": "Internal server error during login"
            }
    
    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        try:
            # Decode refresh token
            payload = self.decode_token(refresh_token)
            
            if payload.get("type") != "refresh":
                logger.warning("Invalid token type for refresh")
                return {
                    "status": "error",
                    "message": "Invalid token type"
                }
            
            username = payload.get("sub")
            user_id = payload.get("user_id")
            role = payload.get("role")
            
            # Verify user still exists and is active
            async with AsyncSessionLocal() as session:
                result = await session.execute(
                    select(User).where(
                        User.id == user_id,
                        User.username == username,
                        User.is_active == True,  # FIXED: Use == instead of just True
                        User.is_deleted == False  # FIXED: Use == instead of not
                    )
                )
                user = result.scalar_one_or_none()
                
                if not user:
                    logger.warning(f"User not found or inactive for token refresh: {username}")
                    return {
                        "status": "error",
                        "message": "User not found or inactive"
                    }
            
            # Create new access token
            access_token_expires = timedelta(minutes=JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
            access_token = self.create_access_token(
                data={
                    "sub": username,
                    "user_id": user_id,
                    "role": role,
                    "firstname": user.firstname,
                    "lastname": user.lastname
                },
                expires_delta=access_token_expires
            )
            
            logger.info(f"Token refreshed for user: {username}")
            
            return {
                "status": "success",
                "access_token": access_token,
                "token_type": "bearer",
                "expires_in": JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60
            }
            
        except jwt.ExpiredSignatureError:
            logger.warning("Refresh token expired")
            return {
                "status": "error",
                "message": "Refresh token expired"
            }
        except jwt.InvalidTokenError:
            logger.warning("Invalid refresh token")
            return {
                "status": "error",
                "message": "Invalid refresh token"
            }
        except Exception as e:
            logger.error(f"Token refresh error: {str(e)}")
            return {
                "status": "error",
                "message": "Internal server error"
            }
    
    async def signup(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Register new user"""
        try:
            logger.info(f"Signup attempt for username: {user_data.get('username')}")
            
            # Validate password strength
            is_valid, error_msg = security_config.validate_password_strength(user_data["password"])
            if not is_valid:
                logger.warning(f"Password validation failed: {error_msg}")
                return {
                    "status": "error",
                    "message": error_msg
                }
            
            async with AsyncSessionLocal() as session:
                # Check if username exists
                result = await session.execute(
                    select(User).where(User.username == user_data["username"])
                )
                existing_user = result.scalar_one_or_none()
                
                if existing_user:
                    logger.warning(f"Username already exists: {user_data['username']}")
                    return {
                        "status": "error",
                        "message": "Username already exists"
                    }
                
                # Check if role exists
                result = await session.execute(
                    select(Role).where(Role.id == user_data["role_id"])
                )
                role = result.scalar_one_or_none()
                
                if not role:
                    logger.warning(f"Role not found: {user_data['role_id']}")
                    return {
                        "status": "error",
                        "message": "Invalid role"
                    }
                
                # Hash password
                hashed_password = await self.get_password_hash(user_data["password"])
                
                # Create user
                user = User(
                    firstname=user_data["firstname"],
                    lastname=user_data["lastname"],
                    username=user_data["username"],
                    password=hashed_password,
                    role_id=user_data["role_id"],
                    is_active=True
                )
                
                session.add(user)
                await session.commit()
                await session.refresh(user)
                
                logger.info(f"User created successfully: {user_data['username']}, role: {role.role}")
                
                return {
                    "status": "success",
                    "message": "User registered successfully",
                    "user_id": user.id,
                    "username": user.username,
                    "role": role.role
                }
                
        except Exception as e:
            logger.error(f"Signup error: {str(e)}")
            return {
                "status": "error",
                "message": f"Error during signup: {str(e)}"
            }
    
    async def change_password(self, user_id: int, current_password: str, new_password: str) -> Dict[str, Any]:
        """Change user password"""
        try:
            async with AsyncSessionLocal() as session:
                # Get user
                result = await session.execute(
                    select(User).where(
                        User.id == user_id,
                        User.is_active == True,  # FIXED
                        User.is_deleted == False  # FIXED
                    )
                )
                user = result.scalar_one_or_none()
                
                if not user:
                    logger.warning(f"User not found for password change: {user_id}")
                    return {
                        "status": "error",
                        "message": "User not found"
                    }
                
                # Verify current password
                if not await self.verify_password(current_password, user.password):
                    logger.warning(f"Incorrect current password for user: {user.username}")
                    return {
                        "status": "error",
                        "message": "Current password is incorrect"
                    }
                
                # Validate new password strength
                is_valid, error_msg = security_config.validate_password_strength(new_password)
                if not is_valid:
                    logger.warning(f"New password validation failed: {error_msg}")
                    return {
                        "status": "error",
                        "message": error_msg
                    }
                
                # Hash new password
                hashed_password = await self.get_password_hash(new_password)
                
                # Update password
                user.password = hashed_password
                await session.commit()
                
                logger.info(f"Password changed successfully for user: {user.username}")
                
                return {
                    "status": "success",
                    "message": "Password changed successfully"
                }
                
        except Exception as e:
            logger.error(f"Password change error: {str(e)}")
            return {
                "status": "error",
                "message": "Error changing password"
            }


# Create singleton instance
login_service = LoginService()