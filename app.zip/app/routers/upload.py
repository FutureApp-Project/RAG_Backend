# app/routers/upload.py
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from app.config.log.log_config import get_logger
from app.services.upload_service import UploadService
from app.schemas.token import TokenData

router = APIRouter(prefix="/upload", tags=["upload"])
logger = get_logger("upload_router")
upload_service = UploadService()
security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)):
    """Verify JWT token and extract user info"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, "your-secret-key", algorithms=["HS256"])
        user_data = TokenData(**payload)
        return user_data
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

@router.post("/pdf")
async def upload_pdf(
    file: UploadFile = File(...),
    user_data: TokenData = Depends(verify_token)
):
    """Upload PDF file (Admin/Doctor only)"""
    try:
        route = router.prefix + "/pdf"
        logger.info(f"Route: {route} | User: {user_data.username} | Role: {user_data.role}")
        
        result = await upload_service.upload_pdf(file, user_data.role)
        
        if result["status"] == "error":
            raise HTTPException(status_code=403, detail=result["message"])
        
        logger.info(f"PDF upload successful: {file.filename}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in upload_pdf endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/cleanup")
async def cleanup_files(user_data: TokenData = Depends(verify_token)):
    """Clean up old uploaded files (Admin only)"""
    try:
        if user_data.role != "admin":
            raise HTTPException(status_code=403, detail="Admin access required")
        
        removed_count = upload_service.cleanup_old_files()
        return {
            "status": "success",
            "message": f"Removed {removed_count} old files"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in cleanup endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")
