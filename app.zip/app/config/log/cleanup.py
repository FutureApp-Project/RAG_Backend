from pathlib import Path
from datetime import datetime, timedelta

LOG_DIR = Path("logs")

def delete_old_logs():
    cutoff = datetime.now() - timedelta(days=30)

    for file in LOG_DIR.glob("*.log"):
        if datetime.fromtimestamp(file.stat().st_mtime) < cutoff:
            file.unlink()
            print("Deleted:", file)
