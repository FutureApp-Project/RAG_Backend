# app/routers/chat.py
from fastapi import APIRouter, Request, HTTPException, Depends, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from typing import Optional, Dict, Any
import uuid
from app.config.log.log_config import get_logger
from app.services.chat_service import ChatService
from app.schemas.token import TokenData
#from app.services.audio_service import create_audio_service

router = APIRouter(prefix="/chat", tags=["chat"])
logger = get_logger("chat_router")
chat_service = ChatService()
security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)):
    """Verify JWT token and extract user info"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, "your-secret-key", algorithms=["HS256"])
        user_data = TokenData(**payload)
        return user_data
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

@router.post("/message")
async def send_message(
    request: Request,
    message_data: Dict[str, Any],
    user_data: TokenData = Depends(verify_token)
):
    """Send message (text/audio/image) with medical image analysis"""
    try:
        route = router.prefix + "/message"
        logger.info(f"Route: {route} | User: {user_data.username}")
        
        # Extract message data
        message_type = message_data.get("type", "text")
        content = message_data.get("content", "")
        session_id = message_data.get("session_id")
        image_type = message_data.get("image_type", "skin")  # skin or scalp
        
        if not content:
            raise HTTPException(status_code=400, detail="Content is required")
        
        # Validate image type
        if message_type == "image" and image_type not in ["skin", "scalp"]:
            raise HTTPException(status_code=400, detail="Image type must be 'skin' or 'scalp'")
        
        # Convert session_id string to UUID if provided
        session_uuid = None
        if session_id:
            try:
                session_uuid = uuid.UUID(session_id)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid session ID format")
        
        # Ensure user_id is present and valid
        if user_data.user_id is None:
            raise HTTPException(status_code=400, detail="User ID is required")
        
        # Process message with image analysis
        result = await chat_service.process_message(
            user_id=user_data.user_id,
            message_type=message_type,
            content=content,
            session_id=session_uuid,
            image_type=image_type if message_type == "image" else "skin"
        )
        
        logger.info(f"Message processed successfully. Image analysis: {message_type == 'image'}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in send_message endpoint: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# New endpoint specifically for medical image analysis
@router.post("/analyze-skin")
async def analyze_skin_image(
    request: Request,
    image_data: Dict[str, Any],
    user_data: TokenData = Depends(verify_token)
):
    """Specialized endpoint for skin condition analysis"""
    try:
        route = router.prefix + "/analyze-skin"
        logger.info(f"Route: {route} | User: {user_data.username}")
        
        base64_image = image_data.get("image")
        if not base64_image:
            raise HTTPException(status_code=400, detail="Image data is required")
        
        # Use image service directly for analysis
        from app.services.image_service import ImageService
        image_service = ImageService()
        
        analysis_result = image_service.process_base64_image(
            base64_image, 
            analyze_medical=True,
            image_type="skin"
        )
        
        logger.info(f"Skin analysis completed for user {user_data.username}")
        
        return {
            "status": "success",
            "analysis": analysis_result,
            "message": "Skin image analyzed successfully",
            "disclaimer": "This is preliminary analysis only. Consult a dermatologist."
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in analyze_skin endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/analyze-scalp")
async def analyze_scalp_image(
    request: Request,
    image_data: Dict[str, Any],
    user_data: TokenData = Depends(verify_token)
):
    """Specialized endpoint for scalp/hair condition analysis"""
    try:
        route = router.prefix + "/analyze-scalp"
        logger.info(f"Route: {route} | User: {user_data.username}")
        
        base64_image = image_data.get("image")
        if not base64_image:
            raise HTTPException(status_code=400, detail="Image data is required")
        
        from app.services.image_service import ImageService
        image_service = ImageService()
        
        analysis_result = image_service.process_base64_image(
            base64_image, 
            analyze_medical=True,
            image_type="scalp"
        )
        
        logger.info(f"Scalp analysis completed for user {user_data.username}")
        
        return {
            "status": "success",
            "analysis": analysis_result,
            "message": "Scalp image analyzed successfully",
            "disclaimer": "This analysis is not a substitute for medical diagnosis."
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in analyze_scalp endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

# ... (keep other endpoints from previous implementation)

@router.get("/history")
async def get_chat_history(
    request: Request,
    session_id: Optional[str] = None,
    user_data: TokenData = Depends(verify_token)
):
    """Get chat history for user"""
    try:
        route = router.prefix + "/history"
        logger.info(f"Route: {route} | User: {user_data.username}")
        
        # Convert session_id string to UUID if provided
        session_uuid = None
        if session_id:
            try:
                session_uuid = uuid.UUID(session_id)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid session ID format")
        
        # Get chat history
        history = await chat_service.get_chat_history(
            user_id=user_data.user_id,
            session_id=session_uuid
        )
        
        logger.info(f"Retrieved chat history for user {user_data.username}")
        return {
            "status": "success",
            "user_id": user_data.user_id,
            "sessions": history
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in get_chat_history endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/sessions")
async def get_user_sessions(
    request: Request,
    user_data: TokenData = Depends(verify_token)
):
    """Get all chat sessions for user"""
    try:
        route = router.prefix + "/sessions"
        logger.info(f"Route: {route} | User: {user_data.username}")
        
        history = await chat_service.get_chat_history(user_id=user_data.user_id)
        
        # Extract only session info
        sessions = [
            {
                "session_id": session["session_id"],
                "title": session["title"],
                "created_at": session["created_at"],
                "message_count": len(session["messages"])
            }
            for session in history
        ]
        
        logger.info(f"Retrieved {len(sessions)} sessions for user {user_data.username}")
        return {
            "status": "success",
            "user_id": user_data.user_id,
            "sessions": sessions
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in get_user_sessions endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")