#app/services/vector_store_service.py:
import chromadb

from langchain_text_splitters import RecursiveCharacterTextSplitter 
from langchain_community.document_loaders import PyPDFLoader
from langchain_ollama import OllamaEmbeddings
import os
import chromadb.errors
from typing import List, Dict, Any, Optional
from app.config.log.log_config import get_logger
import hashlib

logger = get_logger("vector_store_service")

class VectorStoreService:
    def __init__(self, persist_directory: str = "./chromadb"):
        self.persist_directory = persist_directory
        os.makedirs(persist_directory, exist_ok=True)
        
        # Initialize ChromaDB client with persistent storage
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # Get Ollama settings from environment
        ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        ollama_model = os.getenv("EMBEDDING_MODEL", "nomic-embed-text:latest")
        
        # Initialize Ollama embedding model
        self.embedding_model = OllamaEmbeddings(
            base_url=ollama_base_url,
            model=ollama_model
        )
        
        # Initialize text splitter
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=100,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
        logger.info(f"VectorStoreService initialized with Ollama model: {ollama_model}")
        logger.info(f"Ollama base URL: {ollama_base_url}")
        logger.info(f"VectorStoreService initialized with directory: {persist_directory}")
    
    def create_collection(self, collection_name: str = "medical_documents"):
        """Create or get a collection - FIXED VERSION"""
        try:
            # Try to get existing collection
            try:
                collection = self.client.get_collection(name=collection_name)
                count = collection.count()
                # REMOVE Unicode checkmark to avoid encoding error
                logger.info(f"Collection '{collection_name}' exists with {count} documents")
                return collection
            except Exception as e:
                # Check if it's a "not found" error
                error_str = str(e).lower()
                if "not found" in error_str or "does not exist" in error_str:
                    # Collection doesn't exist, create it
                    collection = self.client.create_collection(
                        name=collection_name,
                        metadata={"description": "Medical documents collection"}
                    )
                    logger.info(f"Created new collection '{collection_name}'")
                    return collection
                else:
                    # Some other error, re-raise it
                    raise e
        
        except Exception as e:
            # REMOVE Unicode X symbol
            logger.error(f"Error with collection '{collection_name}': {str(e)}")
            raise
    
    def upload_pdf(self, pdf_path: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Upload and process PDF file, converting to vectors"""
        try:
            if not os.path.exists(pdf_path):
                logger.error(f"PDF file not found: {pdf_path}")
                raise FileNotFoundError(f"PDF file not found: {pdf_path}")
            
            logger.info(f"Processing PDF: {pdf_path}")
            
            # Load PDF document
            loader = PyPDFLoader(pdf_path)
            documents = loader.load()
            logger.info(f"Loaded {len(documents)} pages from PDF")
            
            if not documents:
                logger.warning(f"No content found in PDF: {pdf_path}")
                return {"status": "warning", "message": "No content found in PDF"}
            
            # Split text into chunks
            texts = self.text_splitter.split_documents(documents)
            logger.info(f"Split into {len(texts)} chunks")
            
            # Get or create collection
            collection = self.create_collection("medical_documents")
            
            # Process in batches to avoid batch size limits
            batch_size = 100  # Process 100 chunks at a time
            total_added = 0
            
            for batch_start in range(0, len(texts), batch_size):
                batch_end = min(batch_start + batch_size, len(texts))
                batch_texts = texts[batch_start:batch_end]
                
                # Generate unique IDs for each chunk in this batch
                doc_ids = []
                documents_list = []
                metadatas_list = []
                
                for i, text in enumerate(batch_texts):
                    # Create unique ID based on content and filename
                    content_hash = hashlib.md5(text.page_content.encode()).hexdigest()
                    doc_id = f"{os.path.basename(pdf_path)}_{batch_start + i}_{content_hash[:8]}"
                    
                    # Prepare metadata
                    doc_metadata = {
                        "source": pdf_path,
                        "page": text.metadata.get("page", batch_start + i),
                        "chunk": batch_start + i,
                        "total_chunks": len(texts),
                        "batch": batch_start // batch_size + 1
                    }
                    
                    if metadata:
                        doc_metadata.update(metadata)
                    
                    doc_ids.append(doc_id)
                    documents_list.append(text.page_content)
                    metadatas_list.append(doc_metadata)
                
                # Add batch to collection
                collection.add(
                    documents=documents_list,
                    metadatas=metadatas_list,
                    ids=doc_ids
                )
                
                batch_added = len(batch_texts)
                total_added += batch_added
                logger.info(f"Added batch {batch_start//batch_size + 1}: {batch_added} chunks (total: {total_added}/{len(texts)})")
            
            logger.info(f"Successfully added {total_added} chunks to vector database")
            
            return {
                "status": "success",
                "message": "PDF converted to vectors successfully",
                "filename": os.path.basename(pdf_path),
                "pages": len(documents),
                "chunks": len(texts),
                "batches": (len(texts) + batch_size - 1) // batch_size,
                "collection": "medical_documents"
            }
            
        except Exception as e:
            logger.error(f"Error uploading PDF to vector DB: {str(e)}")
            raise
    
    def query(self, query_text: str, n_results: int = 5) -> Dict[str, Any]:
        """Query the vector database for similar documents"""
        try:
            logger.info(f"Querying vector database: {query_text[:100]}...")
            
            collection = self.client.get_collection("medical_documents")
            
            # Query the collection
            results = collection.query(
                query_texts=[query_text],
                n_results=n_results,
                include=["documents", "metadatas", "distances"]
            )
            
            logger.info(f"Found {len(results['documents'][0])} relevant chunks")
            
            # Process and format results
            formatted_results = []
            for i, (doc, metadata, distance) in enumerate(zip(
                results['documents'][0],
                results['metadatas'][0],
                results['distances'][0]
            )):
                formatted_results.append({
                    "content": doc,
                    "source": metadata.get("source", "Unknown"),
                    "page": metadata.get("page", 0),
                    "similarity_score": 1 - distance,
                    "chunk": metadata.get("chunk", i)
                })
            
            return {
                "query": query_text,
                "results": formatted_results,
                "total_found": len(formatted_results)
            }
            
        except Exception as e:
            logger.error(f"Error querying vector database: {str(e)}")
            return {
                "query": query_text,
                "results": [],
                "total_found": 0,
                "error": str(e)
            }
    
    def get_collection_stats(self, collection_name: str = "medical_documents") -> Dict[str, Any]:
        """Get statistics about the collection"""
        try:
            collection = self.client.get_collection(collection_name)
            count = collection.count()
            
            # Get unique sources
            results = collection.get(include=["metadatas"])
            sources = set()
            for metadata in results["metadatas"]:
                sources.add(metadata.get("source", "Unknown"))
            
            logger.info(f"Collection stats: {count} documents from {len(sources)} sources")
            
            return {
                "collection_name": collection_name,
                "total_documents": count,
                "sources": list(sources),
                "source_count": len(sources)
            }
            
        except Exception as e:
            logger.error(f"Error getting collection stats: {str(e)}")
            return {
                "collection_name": collection_name,
                "error": str(e)
            }
    
    def delete_document(self, source_path: str) -> Dict[str, Any]:
        """Delete all chunks from a specific source document"""
        try:
            collection = self.client.get_collection("medical_documents")
            
            # Get all documents from this source
            results = collection.get(where={"source": source_path})
            
            if results["ids"]:
                # Delete documents
                collection.delete(ids=results["ids"])
                logger.info(f"Deleted {len(results['ids'])} documents from source: {source_path}")
                
                return {
                    "status": "success",
                    "message": f"Deleted {len(results['ids'])} documents",
                    "deleted_count": len(results["ids"])
                }
            else:
                logger.warning(f"No documents found for source: {source_path}")
                return {
                    "status": "warning",
                    "message": "No documents found for this source"
                }
                
        except Exception as e:
            logger.error(f"Error deleting documents: {str(e)}")
            raise
    
    def reset_collection(self, collection_name: str = "medical_documents") -> Dict[str, Any]:
        """Reset/clear the entire collection"""
        try:
            self.client.delete_collection(collection_name)
            logger.info(f"Collection '{collection_name}' deleted")
            
            # Create fresh collection
            self.create_collection(collection_name)
            logger.info(f"Collection '{collection_name}' recreated")
            
            return {
                "status": "success",
                "message": f"Collection '{collection_name}' has been reset"
            }
            
        except Exception as e:
            logger.error(f"Error resetting collection: {str(e)}")
            raise
    
    def list_collections(self) -> List[str]:
        """List all available collections"""
        try:
            collections = self.client.list_collections()
            collection_names = [col.name for col in collections]
            logger.info(f"Available collections: {collection_names}")
            return collection_names
        except Exception as e:
            logger.error(f"Error listing collections: {str(e)}")
            return []