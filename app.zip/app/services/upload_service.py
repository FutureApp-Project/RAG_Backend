#app/services/uploadService.py
# This file can be used to implement upload-related services

import os
import shutil
from typing import Dict, Any
from fastapi import UploadFile
from app.config.log.log_config import get_logger
from app.services.vector_store_service import VectorStoreService
import uuid
from datetime import datetime

logger = get_logger("upload_service")

class UploadService:
    def __init__(self):
        self.vector_store = VectorStoreService()
        self.upload_dir = "./uploads"
        self.processed_dir = "./processed_pdfs"
        
        # Create directories if they don't exist
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.processed_dir, exist_ok=True)
        
        logger.info(f"UploadService initialized")
        logger.info(f"Upload directory: {self.upload_dir}")
        logger.info(f"Processed directory: {self.processed_dir}")
    
    async def upload_pdf(self, file: UploadFile, user_role: str, user_id: int) -> Dict[str, Any]:
        """Upload, save, and process PDF file into vector database"""
        try:
            logger.info(f"PDF upload request from user_id: {user_id}, role: {user_role}")
            
            # Check if user has permission
            if user_role not in ["admin", "doctor"]:
                logger.warning(f"Unauthorized upload attempt by user_id: {user_id}, role: {user_role}")
                return {
                    "status": "error",
                    "message": "Only admin and doctor can upload PDFs"
                }
            
            # Validate file type
            if not file.filename.lower().endswith('.pdf'):
                logger.warning(f"Invalid file type: {file.filename}")
                return {
                    "status": "error",
                    "message": "Only PDF files are allowed"
                }
            
            # Generate unique filename to avoid conflicts
            original_filename = file.filename
            file_extension = original_filename.split('.')[-1]
            unique_filename = f"{uuid.uuid4().hex}.{file_extension}"
            
            # Save uploaded file temporarily
            temp_filepath = os.path.join(self.upload_dir, unique_filename)
            
            logger.info(f"Saving uploaded file to: {temp_filepath}")
            with open(temp_filepath, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            file_size = os.path.getsize(temp_filepath)
            logger.info(f"File saved successfully. Size: {file_size} bytes")
            
            # Prepare metadata
            metadata = {
                "uploaded_by": user_id,
                "user_role": user_role,
                "original_filename": original_filename,
                "upload_date": datetime.now().isoformat(),
                "file_size": file_size
            }
            
            # Process PDF and convert to vectors
            logger.info(f"Starting vector conversion for: {original_filename}")
            vector_result = self.vector_store.upload_pdf(temp_filepath, metadata)
            
            if vector_result["status"] == "success":
                # Move processed file to permanent location
                permanent_filename = f"processed_{original_filename}"
                permanent_path = os.path.join(self.processed_dir, permanent_filename)
                
                # Keep a copy in processed directory
                shutil.copy2(temp_filepath, permanent_path)
                
                # Remove temporary file
                os.remove(temp_filepath)
                
                logger.info(f"PDF successfully processed and converted to vectors: {original_filename}")
                
                # Get collection stats
                stats = self.vector_store.get_collection_stats()
                
                return {
                    "status": "success",
                    "message": "PDF uploaded and converted to vectors successfully",
                    "original_filename": original_filename,
                    "processed_filename": permanent_filename,
                    "vector_result": vector_result,
                    "collection_stats": stats,
                    "metadata": metadata
                }
            else:
                # Remove temporary file if processing failed
                if os.path.exists(temp_filepath):
                    os.remove(temp_filepath)
                
                logger.error(f"Vector conversion failed: {vector_result.get('message', 'Unknown error')}")
                return vector_result
            
        except Exception as e:
            logger.error(f"Error uploading PDF: {str(e)}", exc_info=True)
            
            # Cleanup on error
            temp_filepath = os.path.join(self.upload_dir, unique_filename if 'unique_filename' in locals() else 'unknown')
            if os.path.exists(temp_filepath):
                os.remove(temp_filepath)
            
            return {
                "status": "error",
                "message": f"Error processing PDF: {str(e)}"
            }
    
    def get_uploaded_files(self, user_role: str) -> Dict[str, Any]:
        """Get list of uploaded and processed files"""
        try:
            if user_role not in ["admin", "doctor"]:
                return {"status": "error", "message": "Access denied"}
            
            uploaded_files = []
            if os.path.exists(self.processed_dir):
                for filename in os.listdir(self.processed_dir):
                    filepath = os.path.join(self.processed_dir, filename)
                    if os.path.isfile(filepath) and filename.lower().endswith('.pdf'):
                        file_stats = os.stat(filepath)
                        uploaded_files.append({
                            "filename": filename,
                            "size": file_stats.st_size,
                            "modified": datetime.fromtimestamp(file_stats.st_mtime).isoformat()
                        })
            
            # Get vector database stats
            vector_stats = self.vector_store.get_collection_stats()
            
            logger.info(f"Retrieved {len(uploaded_files)} processed files")
            
            return {
                "status": "success",
                "uploaded_files": uploaded_files,
                "vector_database": vector_stats
            }
            
        except Exception as e:
            logger.error(f"Error getting uploaded files: {str(e)}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def delete_uploaded_file(self, filename: str, user_role: str) -> Dict[str, Any]:
        """Delete an uploaded file and its vectors"""
        try:
            if user_role not in ["admin"]:
                return {"status": "error", "message": "Only admin can delete files"}
            
            filepath = os.path.join(self.processed_dir, filename)
            
            if not os.path.exists(filepath):
                return {"status": "error", "message": "File not found"}
            
            # Remove from vector database first
            delete_result = self.vector_store.delete_document(filepath)
            
            # Remove file
            os.remove(filepath)
            
            logger.info(f"Deleted file and vectors: {filename}")
            
            return {
                "status": "success",
                "message": f"File '{filename}' and its vectors deleted successfully",
                "vector_delete_result": delete_result
            }
            
        except Exception as e:
            logger.error(f"Error deleting file: {str(e)}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def cleanup_old_files(self, days_old: int = 30):
        """Clean up old uploaded files"""
        try:
            import time
            current_time = time.time()
            removed_count = 0
            days_in_seconds = days_old * 24 * 3600
            
            for directory in [self.upload_dir, self.processed_dir]:
                if os.path.exists(directory):
                    for filename in os.listdir(directory):
                        file_path = os.path.join(directory, filename)
                        if os.path.isfile(file_path):
                            file_age = current_time - os.path.getmtime(file_path)
                            if file_age > days_in_seconds:
                                try:
                                    # Also remove from vector database if it's a processed file
                                    if directory == self.processed_dir:
                                        self.vector_store.delete_document(file_path)
                                    
                                    os.remove(file_path)
                                    removed_count += 1
                                    logger.info(f"Removed old file: {filename}")
                                except Exception as e:
                                    logger.warning(f"Could not remove file {filename}: {str(e)}")
            
            logger.info(f"Cleanup completed: removed {removed_count} files older than {days_old} days")
            return removed_count
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
            return 0