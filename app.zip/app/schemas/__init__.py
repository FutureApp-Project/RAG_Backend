# app/schemas/__init__.py
# Import base schemas first
from .user import UserCreate, UserUpdate, UserResponse, UserLogin
from .role import RoleCreate, RoleUpdate, RoleResponse
from .menu import MenuItemCreate, MenuItemUpdate, MenuItemResponse

# Import token schemas
from .token import Token, TokenData, TokenData

# Import chat schemas - order matters due to circular dependencies
# Import the base classes first
from .chat_message import (
    MessageTypeEnum,
    ChatMessageBase, 
    ChatMessageCreate, 
    ChatMessageUpdate,
    ChatMessageResponse
)

from .chat_sessions import (
    ChatSessionBase,
    ChatSessionCreate, 
    ChatSessionUpdate, 
    ChatSessionResponse,
    ChatSessionWithMessagesResponse,
    ChatSessionListResponse,
    ChatSessionStatsResponse,
    ChatSessionQuery,
    ChatSessionBulkDelete,
    ChatSessionExportRequest,
    ChatSessionExportResponse,
    ChatSessionSummaryResponse,
    ChatSessionCreateResponse,
    ChatSessionDeleteResponse
)


__all__ = [
    # User schemas
    "UserCreate", "UserUpdate", "UserResponse", "UserLogin",
    # Role schemas
    "RoleCreate", "RoleUpdate", "RoleResponse",
    # Menu schemas
    "MenuItemCreate", "MenuItemUpdate", "MenuItemResponse",
    # Token schemas
    "Token", "TokenData", "TokenPayload",
    # Chat message schemas
    "MessageTypeEnum",
    "ChatMessageBase", "ChatMessageCreate", "ChatMessageUpdate", "ChatMessageResponse",
    # Chat session schemas
    "ChatSessionBase", "ChatSessionCreate", "ChatSessionUpdate", "ChatSessionResponse",
    "ChatSessionWithMessagesResponse", "ChatSessionListResponse", "ChatSessionStatsResponse",
    "ChatSessionQuery", "ChatSessionBulkDelete", "ChatSessionExportRequest",
    "ChatSessionExportResponse", "ChatSessionSummaryResponse", "ChatSessionCreateResponse",
    "ChatSessionDeleteResponse",
]